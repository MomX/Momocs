library(testthat)
library(trackter)

test_check("trackter")
